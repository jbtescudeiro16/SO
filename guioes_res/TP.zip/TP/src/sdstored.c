#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>


int main(int argc, char *argv[]){

    mkfifo("client_server", 0664);

    int read_pipe = open("client_server", O_RDONLY);
    int close_pipe = open("client_server", O_WRONLY);

    char buffer[1024];
    int n_bytes = 0;
    while((n_bytes = read(read_pipe, buffer, sizeof(buffer))) > 0){
        buffer[n_bytes] = 0;
        char *args[20];
        int i = 0;
        for(char *token = strtok(buffer, " "); token != NULL; token = strtok(NULL, " ")){
            args[i++] = strdup(token);
        }

        int n_transf = i;
        if(!fork()){
            if(n_transf == 3){
                int fd1 = open(args[0], O_RDONLY); 
                dup2(fd1, 0);
                int fd2 = open(args[1], O_WRONLY | O_CREAT | O_TRUNC); 
                dup2(fd2, 1);
                execl(args[2], args[2], NULL);
            }
            else{
            int pd[n_transf - 1][2];
            int current_pipe = 0;

            for(int i = 2; i < n_transf; ++i){
                if(i == 2){
                    pipe(pd[current_pipe]);
                    if(!fork()){
                        close(pd[current_pipe][0]);
                        int fd = open(args[0], O_RDONLY);
                        if(fd < 0){
                            perror("Error opening file");
                            _exit(1);
                        }

                        dup2(fd, 0);
                        close(fd);
                        dup2(pd[current_pipe][1], 1);
                        execlp(args[i], args[i], NULL);
                    }
                    else{
                        close(pd[current_pipe][1]); 
                        current_pipe++;
                    }
                }                
                else if(i == n_transf - 1){
                    if(!fork()){
                        int fd = open(args[1], O_WRONLY | O_CREAT | O_TRUNC);
                        if(fd < 0){
                            perror("Error opening file");
                            _exit(1);
                        }
                        dup2(fd, 1);
                        close(fd);
                        dup2(pd[current_pipe - 1][0], 0);
                        close(pd[current_pipe - 1][0]);
                        execlp(args[i], args[i], NULL);
                    }
                    else{
                        close(pd[current_pipe - 1][0]);
                    }
                }
                else{
                    pipe(pd[current_pipe]);
                    if(!fork()){
                        close(pd[current_pipe][0]);
                        dup2(pd[current_pipe - 1][0], 0);
                        close(pd[current_pipe - 1][0]);
                        dup2(pd[current_pipe][1], 1);
                        execlp(args[i], args[i], NULL);
                    }
                    else{
                        close(pd[current_pipe][1]);
                        close(pd[current_pipe - 1][0]);
                        current_pipe++;
                    }
                }
            }
            }
        } 
    }

    return 0;
}
