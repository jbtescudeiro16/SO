#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>

//falta verificar aqui algumas condições

int main(int argc, char *argv[]){

    char buffer[1024];
    int n_bytes = 0;
    for(int i = 1; i < argc; ++i){
        n_bytes += snprintf(buffer + n_bytes, sizeof(buffer) - n_bytes, "%s ", argv[i]); 
    }

    int write_pipe = open("client_server", O_WRONLY);
    write(write_pipe, buffer, n_bytes);
    close(write_pipe);

    return 0;
}
