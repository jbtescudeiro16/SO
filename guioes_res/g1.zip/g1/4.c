//ignorar linhas vazias 

//primeiro imprimir o contaoor 
//depois fazer write do conteudo do buffer para o stdoutput
//so incrementar o contador se o caractere \n for encontrado 

//snprintf (buffer,"%d",contador)


//depois 